"""ClubSpark backend. Run from this folder:  uvicorn main:app --reload"""
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

load_dotenv(Path(__file__).parent / ".env")

import prompts  # noqa: E402  (after load_dotenv so env vars are ready)
from providers import LLMError, available_providers, generate  # noqa: E402

app = FastAPI(title="ClubSpark API")


class Club(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    type: str = Field(default="", max_length=80)
    members: int = Field(default=30, ge=1, le=100000)
    budget: str = Field(default="", max_length=80)
    audience: str = Field(default="students", max_length=80)
    tone: str = Field(default="fun and energetic", max_length=60)


class Event(BaseModel):
    date: str = ""
    start_time: str = ""
    end_time: str = ""
    venue: str = Field(default="", max_length=120)


class IdeasRequest(BaseModel):
    club: Club
    theme: str = Field(default="", max_length=200)
    count: int = Field(default=5, ge=1, le=8)
    provider: Optional[str] = None


class PlanRequest(BaseModel):
    club: Club
    idea: dict
    event: Event = Event()
    provider: Optional[str] = None


class AnnouncementRequest(PlanRequest):
    extra: str = Field(default="", max_length=500)


class PosterRequest(PlanRequest):
    vibe: str = Field(default="bold and modern", max_length=80)


async def _run(task: str, prompt: str, provider: Optional[str]) -> dict:
    try:
        return await generate(task, prompt, provider)
    except LLMError as e:
        raise HTTPException(status_code=502, detail=str(e))


@app.get("/api/providers")
def providers():
    return {"providers": available_providers()}


@app.post("/api/ideas")
async def ideas(req: IdeasRequest):
    p = prompts.ideas_prompt(req.club.model_dump(), req.theme, req.count)
    return await _run("ideas", p, req.provider)


@app.post("/api/schedule")
async def schedule(req: PlanRequest):
    p = prompts.schedule_prompt(req.club.model_dump(), req.idea, req.event.model_dump())
    return await _run("schedule", p, req.provider)


@app.post("/api/announcement")
async def announcement(req: AnnouncementRequest):
    p = prompts.announcement_prompt(req.club.model_dump(), req.idea, req.event.model_dump(), req.extra)
    return await _run("announcement", p, req.provider)


@app.post("/api/poster")
async def poster(req: PosterRequest):
    p = prompts.poster_prompt(req.club.model_dump(), req.idea, req.event.model_dump(), req.vibe)
    return await _run("poster", p, req.provider)


# Serve the UI last so /api routes win.
FRONTEND = Path(__file__).resolve().parent.parent / "frontend"
app.mount("/", StaticFiles(directory=FRONTEND, html=True), name="frontend")
