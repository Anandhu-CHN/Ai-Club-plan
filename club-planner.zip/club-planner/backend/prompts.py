"""Prompt templates. Every prompt asks for strict JSON so the UI can render real components."""
import json


def _club_block(club: dict) -> str:
    return (
        f"Club name: {club['name']}\n"
        f"Club type: {club['type'] or 'general student club'}\n"
        f"Members: {club['members']}\n"
        f"Budget: {club['budget'] or 'small / unspecified'}\n"
        f"Audience: {club['audience']}\n"
        f"Tone: {club['tone']}"
    )


def _event_block(event: dict) -> str:
    parts = []
    if event.get("date"):
        parts.append(f"Date: {event['date']}")
    if event.get("start_time") or event.get("end_time"):
        parts.append(f"Time: {event.get('start_time') or '?'} to {event.get('end_time') or '?'}")
    if event.get("venue"):
        parts.append(f"Venue: {event['venue']}")
    return "\n".join(parts) or "No date, time or venue given yet."


def ideas_prompt(club: dict, theme: str, count: int) -> str:
    return f"""You plan events for student clubs. Suggest {count} distinct, realistic event ideas.

{_club_block(club)}
Theme or goal: {theme or 'open - surprise me'}

Rules: ideas must fit the budget, be doable by students, and differ clearly from each other.
Return ONLY JSON in this shape:
{{"ideas": [{{"title": "", "tagline": "", "description": "2-3 sentences", "duration": "e.g. 3 hours",
"estimated_budget": "e.g. Low / about 2000 INR", "difficulty": "Easy|Medium|Hard", "why_it_works": "one sentence"}}]}}"""


def schedule_prompt(club: dict, idea: dict, event: dict) -> str:
    return f"""Create a minute-by-minute run sheet for this student club event.

{_club_block(club)}
Event idea: {json.dumps(idea)}
{_event_block(event)}

Rules: start and end within the given times when provided; include setup and wrap-up; assign an owner role to each item.
Return ONLY JSON in this shape:
{{"title": "", "items": [{{"time": "HH:MM", "activity": "", "duration_min": 0, "owner": "", "notes": ""}}],
"materials": [""], "tips": [""]}}"""


def announcement_prompt(club: dict, idea: dict, event: dict, extra: str) -> str:
    return f"""Write announcements for this student club event, one per channel, matching the tone.

{_club_block(club)}
Event idea: {json.dumps(idea)}
{_event_block(event)}
Extra details to include: {extra or 'none'}

Rules: WhatsApp is short and chatty with a clear ask; Instagram has a hook and 3-5 hashtags; email has a subject and a
clear body with the logistics; the notice board text is formal, brief and scannable. Never invent facts that are not given.
Return ONLY JSON in this shape:
{{"whatsapp": "", "instagram": "", "email_subject": "", "email_body": "", "notice_board": ""}}"""


def poster_prompt(club: dict, idea: dict, event: dict, vibe: str) -> str:
    return f"""Design the text and colors for an event poster.

{_club_block(club)}
Event idea: {json.dumps(idea)}
{_event_block(event)}
Visual vibe: {vibe}

Rules: headline max 6 words; subheadline max 12 words; details max 4 short lines (use the real date/time/venue when given);
cta max 6 words; palette uses 6-digit hex colors with strong contrast between text and bg1/bg2; emoji is a single emoji.
Return ONLY JSON in this shape:
{{"headline": "", "subheadline": "", "details": [""], "cta": "",
"palette": {{"bg1": "#000000", "bg2": "#000000", "accent": "#000000", "text": "#ffffff"}}, "emoji": ""}}"""
