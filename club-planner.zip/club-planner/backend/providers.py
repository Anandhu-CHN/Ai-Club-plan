"""LLM provider wrappers. The browser never sees an API key: only this backend does."""
import json
import os
import re

import httpx


class LLMError(Exception):
    """Raised when a provider fails or returns unusable output."""


def available_providers() -> list[str]:
    found = []
    if os.getenv("GEMINI_API_KEY"):
        found.append("gemini")
    if os.getenv("OPENAI_API_KEY"):
        found.append("openai")
    found.append("mock")  # always available so the UI works without keys
    return found


def _extract_json(text: str):
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.MULTILINE).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"(\{.*\}|\[.*\])", text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(1))
            except json.JSONDecodeError:
                pass
    raise LLMError("The model did not return valid JSON. Try again.")


async def _gemini(prompt: str) -> str:
    key = os.getenv("GEMINI_API_KEY")
    if not key:
        raise LLMError("GEMINI_API_KEY is not set in backend/.env")
    model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"responseMimeType": "application/json", "temperature": 0.9},
    }
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(url, params={"key": key}, json=body)
    if r.status_code != 200:
        raise LLMError(f"Gemini error {r.status_code}: {r.text[:200]}")
    try:
        return r.json()["candidates"][0]["content"]["parts"][0]["text"]
    except (KeyError, IndexError):
        raise LLMError("Gemini returned an empty response (it may have been blocked).")


async def _openai(prompt: str) -> str:
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        raise LLMError("OPENAI_API_KEY is not set in backend/.env")
    model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    body = {
        "model": model,
        "messages": [
            {"role": "system", "content": "You are a creative assistant for student clubs. Reply with JSON only."},
            {"role": "user", "content": prompt},
        ],
        "response_format": {"type": "json_object"},
        "temperature": 0.9,
    }
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {key}"},
            json=body,
        )
    if r.status_code != 200:
        raise LLMError(f"OpenAI error {r.status_code}: {r.text[:200]}")
    try:
        return r.json()["choices"][0]["message"]["content"]
    except (KeyError, IndexError):
        raise LLMError("OpenAI returned an empty response.")


def _mock(task: str) -> dict:
    """Canned data so you can build and demo the UI with no API key."""
    if task == "ideas":
        return {"ideas": [
            {"title": "Midnight Hackathon Lite", "tagline": "Build something silly in 4 hours",
             "description": "Teams of 3 build a tiny project around a surprise theme, then demo it in 60 seconds each.",
             "duration": "4 hours", "estimated_budget": "Low", "difficulty": "Medium",
             "why_it_works": "Short, social, and no experience needed."},
            {"title": "Skill Swap Saturday", "tagline": "Teach one thing, learn one thing",
             "description": "Members run 15-minute micro-workshops on anything they are good at.",
             "duration": "2 hours", "estimated_budget": "Very low", "difficulty": "Easy",
             "why_it_works": "Every member contributes, so attendance stays high."},
            {"title": "Club Olympics", "tagline": "Friendly chaos, real bragging rights",
             "description": "Mini-games and relay challenges between teams with a trophy made from scrap.",
             "duration": "3 hours", "estimated_budget": "Low", "difficulty": "Easy",
             "why_it_works": "Great for new-member bonding and photos."},
        ]}
    if task == "schedule":
        return {"title": "Event run sheet", "items": [
            {"time": "10:00", "activity": "Setup and registration", "duration_min": 30, "owner": "Logistics team", "notes": "Name tags at the door"},
            {"time": "10:30", "activity": "Welcome and rules", "duration_min": 15, "owner": "President", "notes": ""},
            {"time": "10:45", "activity": "Main activity", "duration_min": 90, "owner": "All teams", "notes": "Keep a 5-minute warning"},
            {"time": "12:15", "activity": "Showcase and voting", "duration_min": 30, "owner": "Emcee", "notes": ""},
            {"time": "12:45", "activity": "Wrap-up and photos", "duration_min": 15, "owner": "Media team", "notes": "Collect feedback form"},
        ], "materials": ["Name tags", "Markers", "Timer", "Snacks"],
            "tips": ["Confirm the venue 2 days before", "Assign one person to watch the clock"]}
    if task == "announcement":
        return {"whatsapp": "Hey everyone! Our next event is coming up. Save the date and bring a friend. Reply YES if you are in!",
                "instagram": "Something fun is coming. Save the date and tag a friend you are bringing. #ClubLife #CampusEvents",
                "email_subject": "You are invited: our next club event",
                "email_body": "Hi all,\n\nWe are excited to invite you to our next event. Details are below. Please reply to confirm your spot.\n\nSee you there,\nThe Club Team",
                "notice_board": "CLUB EVENT. Open to all students. See details below. Register with any committee member."}
    if task == "poster":
        return {"headline": "Build. Laugh. Repeat.", "subheadline": "A casual event for everyone",
                "details": ["Open to all students", "Snacks provided", "Free entry"], "cta": "Register at the club desk",
                "palette": {"bg1": "#1b1340", "bg2": "#6c3cc9", "accent": "#7cf5c8", "text": "#ffffff"}, "emoji": "✨"}
    return {}


async def generate(task: str, prompt: str, provider: str | None = None) -> dict:
    provider = (provider or os.getenv("DEFAULT_PROVIDER") or "").lower()
    if not provider or provider == "auto":
        provider = available_providers()[0]
    if provider == "mock":
        return _mock(task)
    if provider == "gemini":
        return _extract_json(await _gemini(prompt))
    if provider == "openai":
        return _extract_json(await _openai(prompt))
    raise LLMError(f"Unknown provider: {provider}")
