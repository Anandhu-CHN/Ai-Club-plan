# ClubSpark - AI club activity planner

Generates event ideas, run-sheet schedules, announcements (WhatsApp, Instagram, email, notice board)
and downloadable posters for student clubs.

## Run it

```bash
cd backend
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env             # Windows: copy .env.example .env  (then add your key)
uvicorn main:app --reload
```

Open http://127.0.0.1:8000

No API key yet? Choose "mock" in the AI model dropdown to try the whole UI with sample data.

## Keys
- Gemini: https://aistudio.google.com/apikey
- OpenAI: https://platform.openai.com/api-keys

## Structure
- backend/main.py       FastAPI routes + serves the frontend
- backend/providers.py  Gemini / OpenAI / mock wrappers
- backend/prompts.py    prompt templates (edit these to change output quality)
- frontend/             index.html, style.css, app.js
