const $ = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];

const state = { selected: null, poster: null };

const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

/* ---------------- helpers ---------------- */
function toast(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => t.classList.remove("show"), 2200);
}

function formData() {
  const d = new FormData($("#club-form"));
  return {
    club: {
      name: (d.get("name") || "").trim(),
      type: (d.get("type") || "").trim(),
      members: Number(d.get("members")) || 30,
      budget: (d.get("budget") || "").trim(),
      audience: (d.get("audience") || "").trim() || "students",
      tone: d.get("tone"),
    },
    event: {
      date: d.get("date") || "",
      start_time: d.get("start_time") || "",
      end_time: d.get("end_time") || "",
      venue: (d.get("venue") || "").trim(),
    },
    provider: $("#provider").value,
  };
}

async function api(path, body) {
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const detail = Array.isArray(data.detail) ? "Please check the form fields." : data.detail;
    throw new Error(detail || `Request failed (${res.status})`);
  }
  return data;
}

function skeleton(target) {
  target.innerHTML = '<div class="skeleton"><span></span><span></span><span></span></div>';
}

function needClubName() {
  if (!formData().club.name) {
    toast("Add your club name first");
    $('input[name="name"]').focus();
    return true;
  }
  return false;
}

function needIdea() {
  if (!state.selected) {
    toast("Pick an idea first");
    switchTab("ideas");
    return true;
  }
  return false;
}

async function run(button, target, job) {
  button.disabled = true;
  const label = button.textContent;
  button.textContent = "Thinking...";
  skeleton(target);
  try {
    await job();
  } catch (err) {
    target.innerHTML = `<div class="error">${esc(err.message)}</div>`;
  } finally {
    button.disabled = false;
    button.textContent = label;
  }
}

/* ---------------- tabs ---------------- */
function moveIndicator() {
  const active = $(".tabs button.active");
  const ind = $("#indicator");
  ind.style.width = active.offsetWidth + "px";
  ind.style.transform = `translateX(${active.offsetLeft}px)`;
}

function switchTab(name) {
  $$(".tabs button").forEach((b) => b.classList.toggle("active", b.dataset.tab === name));
  $$(".panel").forEach((p) => p.classList.toggle("active", p.dataset.panel === name));
  moveIndicator();
}

$("#tabs").addEventListener("click", (e) => {
  const btn = e.target.closest("button");
  if (!btn) return;
  if (btn.dataset.tab !== "ideas" && needIdea()) return;
  switchTab(btn.dataset.tab);
});
window.addEventListener("resize", moveIndicator);

/* ---------------- ideas ---------------- */
function renderIdeas(ideas) {
  const out = $("#out-ideas");
  if (!ideas.length) {
    out.innerHTML = '<p class="empty">No ideas came back. Try again.</p>';
    return;
  }
  out.innerHTML = '<div class="cards">' + ideas.map((i, n) => `
    <article class="card" style="animation-delay:${n * 70}ms">
      <h3>${esc(i.title)}</h3>
      <p class="tag">${esc(i.tagline)}</p>
      <p>${esc(i.description)}</p>
      <div class="chips">
        <span class="chip">${esc(i.duration)}</span>
        <span class="chip">${esc(i.estimated_budget)}</span>
        <span class="chip">${esc(i.difficulty)}</span>
      </div>
      <p class="muted">${esc(i.why_it_works)}</p>
      <button class="btn" data-pick="${n}">Use this idea</button>
    </article>`).join("") + "</div>";

  $$("[data-pick]", out).forEach((btn) =>
    btn.addEventListener("click", () => {
      state.selected = ideas[Number(btn.dataset.pick)];
      $$(".card", out).forEach((c) => c.classList.remove("chosen"));
      btn.closest(".card").classList.add("chosen");
      $("#selected-title").textContent = state.selected.title;
      $("#selected").hidden = false;
      toast("Idea selected. Open the other tabs.");
    })
  );
}

/* ---------------- schedule ---------------- */
function renderSchedule(s) {
  const items = (s.items || []).map((it, n) => `
    <li style="animation-delay:${n * 60}ms">
      <time>${esc(it.time)}</time>
      <strong>${esc(it.activity)}</strong>
      <small>${esc(it.duration_min)} min${it.owner ? " - " + esc(it.owner) : ""}${it.notes ? " - " + esc(it.notes) : ""}</small>
    </li>`).join("");
  const list = (arr) => (arr || []).map((x) => `<li>${esc(x)}</li>`).join("");
  $("#out-schedule").innerHTML = `
    <h3>${esc(s.title || state.selected.title)}</h3>
    <ul class="timeline">${items}</ul>
    <div class="two">
      <div class="card"><h4>Materials</h4><ul>${list(s.materials)}</ul></div>
      <div class="card"><h4>Tips</h4><ul>${list(s.tips)}</ul></div>
    </div>`;
}

/* ---------------- announcements ---------------- */
function renderAnnouncements(a) {
  const blocks = [
    ["WhatsApp", a.whatsapp],
    ["Instagram", a.instagram],
    ["Email", `Subject: ${a.email_subject || ""}\n\n${a.email_body || ""}`],
    ["Notice board", a.notice_board],
  ];
  const out = $("#out-announce");
  out.innerHTML = '<div class="cards">' + blocks.map(([title, text], n) => `
    <article class="card" style="animation-delay:${n * 70}ms">
      <div class="msg-head"><h3>${title}</h3><button class="copy" data-copy="${n}">Copy</button></div>
      <p class="msg">${esc(text)}</p>
    </article>`).join("") + "</div>";

  $$("[data-copy]", out).forEach((btn) =>
    btn.addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(blocks[Number(btn.dataset.copy)][1] || "");
        toast("Copied");
      } catch {
        toast("Could not copy. Select the text instead.");
      }
    })
  );
}

/* ---------------- poster (canvas) ---------------- */
const hex = (v, fallback) => (/^#[0-9a-f]{6}$/i.test(v || "") ? v : fallback);

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
  let line = "";
  for (const word of String(text).split(" ")) {
    const test = line ? line + " " + word : word;
    if (ctx.measureText(test).width > maxWidth && line) {
      ctx.fillText(line, x, y);
      line = word;
      y += lineHeight;
    } else {
      line = test;
    }
  }
  ctx.fillText(line, x, y);
  return y + lineHeight;
}

function drawPoster(p) {
  const canvas = $("#poster-canvas");
  const ctx = canvas.getContext("2d");
  const W = canvas.width, H = canvas.height;
  const pal = p.palette || {};
  const bg1 = hex(pal.bg1, "#1b1340"), bg2 = hex(pal.bg2, "#6c3cc9");
  const accent = hex(pal.accent, "#7cf5c8"), text = hex(pal.text, "#ffffff");
  const font = '"Sora", system-ui, sans-serif';

  const g = ctx.createLinearGradient(0, 0, W, H);
  g.addColorStop(0, bg1);
  g.addColorStop(1, bg2);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);

  [[0.85, 0.12, 330, 0.35], [0.1, 0.88, 380, 0.3], [0.5, 0.5, 220, 0.12]].forEach(([cx, cy, r, a]) => {
    ctx.globalAlpha = a;
    ctx.fillStyle = accent;
    ctx.beginPath();
    ctx.arc(cx * W, cy * H, r, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.globalAlpha = 1;

  // glass panel
  roundRect(ctx, 80, 150, W - 160, H - 300, 48);
  ctx.fillStyle = "rgba(255,255,255,0.14)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.4)";
  ctx.lineWidth = 3;
  ctx.stroke();

  ctx.textAlign = "center";
  ctx.fillStyle = accent;
  ctx.font = `600 36px ${font}`;
  ctx.fillText((formData().club.name || "").toUpperCase(), W / 2, 110);

  ctx.font = "150px serif";
  ctx.fillText(p.emoji || "✨", W / 2, 360);

  ctx.fillStyle = text;
  ctx.font = `700 100px ${font}`;
  let y = wrapText(ctx, p.headline || "", W / 2, 520, W - 260, 112);

  ctx.font = `300 44px ${font}`;
  y = wrapText(ctx, p.subheadline || "", W / 2, y + 10, W - 280, 58);

  ctx.fillStyle = accent;
  ctx.fillRect(W / 2 - 60, y + 10, 120, 6);

  ctx.fillStyle = text;
  ctx.font = `400 42px ${font}`;
  y += 90;
  (p.details || []).slice(0, 4).forEach((d) => {
    y = wrapText(ctx, d, W / 2, y, W - 280, 54) + 8;
  });

  // call to action pill
  const cta = p.cta || "";
  if (cta) {
    ctx.font = `600 40px ${font}`;
    const w = Math.min(ctx.measureText(cta).width + 100, W - 200);
    roundRect(ctx, W / 2 - w / 2, H - 290, w, 90, 45);
    ctx.fillStyle = accent;
    ctx.fill();
    ctx.fillStyle = bg1;
    ctx.fillText(cta, W / 2, H - 230);
  }
}

function showPoster(p) {
  state.poster = p;
  $("#poster-empty").hidden = true;
  $("#poster-canvas").hidden = false;
  $("#download").hidden = false;
  const draw = () => drawPoster(p);
  if (document.fonts && document.fonts.load) {
    Promise.all([document.fonts.load('700 100px "Sora"'), document.fonts.load('300 44px "Sora"')]).then(draw, draw);
  } else draw();
}

$("#download").addEventListener("click", () => {
  const a = document.createElement("a");
  a.download = "club-poster.png";
  a.href = $("#poster-canvas").toDataURL("image/png");
  a.click();
});

/* ---------------- actions ---------------- */
const actions = {
  async ideas(btn) {
    if (needClubName()) return;
    const f = formData();
    await run(btn, $("#out-ideas"), async () => {
      const data = await api("/api/ideas", {
        club: f.club, provider: f.provider,
        theme: $("#theme").value.trim(), count: Number($("#count").value),
      });
      state.selected = null;
      $("#selected").hidden = true;
      renderIdeas(data.ideas || []);
    });
  },
  async schedule(btn) {
    if (needClubName() || needIdea()) return;
    const f = formData();
    await run(btn, $("#out-schedule"), async () => {
      renderSchedule(await api("/api/schedule", { ...f, idea: state.selected }));
    });
  },
  async announce(btn) {
    if (needClubName() || needIdea()) return;
    const f = formData();
    await run(btn, $("#out-announce"), async () => {
      renderAnnouncements(await api("/api/announcement", { ...f, idea: state.selected, extra: $("#extra").value.trim() }));
    });
  },
  async poster(btn) {
    if (needClubName() || needIdea()) return;
    const f = formData();
    const out = $("#out-poster");
    const canvas = $("#poster-canvas");
    const empty = $("#poster-empty");
    canvas.hidden = true;
    $("#download").hidden = true;
    empty.hidden = false;
    btn.disabled = true;
    const label = btn.textContent;
    btn.textContent = "Thinking...";
    empty.className = "empty";
    empty.textContent = "Designing your poster...";
    try {
      showPoster(await api("/api/poster", { ...f, idea: state.selected, vibe: $("#vibe").value }));
    } catch (err) {
      empty.className = "error";
      empty.textContent = err.message;
    } finally {
      btn.disabled = false;
      btn.textContent = label;
    }
  },
};

$$("[data-action]").forEach((btn) => btn.addEventListener("click", () => actions[btn.dataset.action](btn)));

/* ---------------- init ---------------- */
(async function init() {
  const select = $("#provider");
  try {
    const res = await fetch("/api/providers");
    const { providers } = await res.json();
    select.innerHTML = '<option value="auto">Auto (best available)</option>' +
      providers.map((p) => `<option value="${esc(p)}">${esc(p === "mock" ? "mock (demo, no API)" : p)}</option>`).join("");
  } catch {
    select.innerHTML = '<option value="mock">mock (demo, no API)</option>';
  }
  requestAnimationFrame(moveIndicator);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(moveIndicator);
})();
